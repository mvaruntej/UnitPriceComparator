import React, { useEffect, useMemo, useState } from "react";

/**
 * Unit Price Comparator — Web (pure React, no native deps)
 *
 * This version runs in the canvas without Expo/Native modules.
 * Features:
 *  - Compare unit prices across sizes & multipacks (mass/volume/count)
 *  - Normalize to any base (e.g., per 100 g / 100 ml / per piece)
 *  - Promos: percent off, flat off, Buy X Get Y
 *  - CSV import (file or paste) & export (download)
 *  - Local persistence (localStorage)
 *  - Built-in self tests (shown at bottom)
 */

// -------------------------- Types & constants --------------------------

/** @typedef {"mass"|"volume"|"count"} MeasureKind */

const MASS_UNITS = [
  { key: "g", label: "g", toBase: (v) => v },
  { key: "kg", label: "kg", toBase: (v) => v * 1000 },
];
const VOL_UNITS = [
  { key: "ml", label: "ml", toBase: (v) => v },
  { key: "l", label: "L", toBase: (v) => v * 1000 },
];
const COUNT_UNITS = [
  { key: "count", label: "unit(s)", toBase: (v) => v },
];
const KIND_UNITS = { mass: MASS_UNITS, volume: VOL_UNITS, count: COUNT_UNITS };

/**
 * @typedef {Object} Item
 * @property {string} name
 * @property {number} qty
 * @property {string} unit
 * @property {number} packs
 * @property {number} price
 * @property {number=} percentOff
 * @property {number=} flatOff
 * @property {number=} buyX
 * @property {number=} getY
 * @property {string=} notes
 */

const DEFAULT_ITEMS = [
  { name: "Coffee 100 g", qty: 100, unit: "g", packs: 1, price: 149 },
  { name: "Coffee 500 g", qty: 500, unit: "g", packs: 1, price: 649, notes: "Family pack" },
  { name: "Coffee 5×100 g", qty: 100, unit: "g", packs: 5, price: 699, notes: "Multi-pack" },
];

function currencyFormat(n, currency) {
  if (!isFinite(n)) return "-";
  try {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format(n);
  } catch {
    // If user enters a symbol instead of ISO code, just prefix it
    return `${currency}${Number(n).toFixed(2)}`;
  }
}

const styles = {
  page: { fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, Arial, sans-serif", background: "#f8fafc", minHeight: "100vh", padding: 16 },
  container: { maxWidth: 1100, margin: "0 auto" },
  h1: { fontSize: 28, fontWeight: 800, margin: 0 },
  sub: { color: "#475569", marginTop: 4 },
  card: { background: "#fff", borderRadius: 16, padding: 12, boxShadow: "0 4px 16px rgba(0,0,0,0.05)", marginTop: 16 },
  row: { display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" },
  label: { fontSize: 12, color: "#475569", marginBottom: 4 },
  input: { border: "1px solid #cbd5e1", borderRadius: 12, padding: "8px 10px", fontSize: 16 },
  smallInput: { border: "1px solid #cbd5e1", borderRadius: 10, padding: "6px 8px", fontSize: 14, width: 90 },
  select: { border: "1px solid #cbd5e1", borderRadius: 12, padding: "8px 10px", fontSize: 16, background: "#fff" },
  btn: { border: "1px solid #0f172a", borderRadius: 12, padding: "10px 14px", background: "#fff", cursor: "pointer", fontWeight: 700 },
  btnFilled: { border: "1px solid #0f172a", borderRadius: 12, padding: "10px 14px", background: "#0f172a", cursor: "pointer", color: "#fff", fontWeight: 700 },
  headerRow: { display: "grid", gridTemplateColumns: "3fr 1fr 1fr 1fr 2fr 2fr 2fr 1fr", gap: 8, borderBottom: "1px solid #e2e8f0", paddingBottom: 6, marginBottom: 6, fontSize: 12, color: "#475569" },
  itemRow: { display: "grid", gridTemplateColumns: "3fr 1fr 1fr 1fr 2fr 2fr 2fr 1fr", gap: 8, alignItems: "center", padding: "8px 0", borderBottom: "1px solid #e2e8f0" },
  bestBadge: { background: "#059669", color: "#fff", padding: "4px 8px", borderRadius: 8, fontSize: 12, fontWeight: 800 },
  pasteBox: { marginTop: 12, border: "1px solid #cbd5e1", borderRadius: 12, padding: 10, background: "#fff", minHeight: 120, width: "100%" },
};

// ------------------------------- CSV ----------------------------------
function escapeCSVField(v) {
  const s = String(v ?? "");
  const needsQuotes = /[",\n\r]/.test(s);
  const escaped = s.replace(/"/g, '""');
  return needsQuotes ? `"${escaped}"` : escaped;
}

function toCSV(data) {
  const header = [
    "name","qty","unit","packs","price","percentOff","flatOff","buyX","getY","notes",
  ];
  const lines = data.map((it) => [
    it.name,
    it.qty,
    it.unit,
    it.packs,
    it.price,
    it.percentOff ?? "",
    it.flatOff ?? "",
    it.buyX ?? "",
    it.getY ?? "",
    it.notes ?? "",
  ].map(escapeCSVField).join(","));
  return header.join(",") + "\\n" + lines.join("\\n");
}

function parseCSV(csv) {
  // Lightweight CSV parser for common cases (handles quotes, CRLF/LF)
  const rows = [];
  let cell = ""; let row = []; let inQ = false;
  for (let i = 0; i < csv.length; i++) {
    const ch = csv[i];
    if (inQ) {
      if (ch === '"' && csv[i + 1] === '"') { cell += '"'; i++; }
      else if (ch === '"') inQ = false;
      else cell += ch;
    } else {
      if (ch === '"') inQ = true;
      else if (ch === ',') { row.push(cell); cell = ""; }
      else if (ch === '\\n') { row.push(cell); rows.push(row); cell = ""; row = []; }
      else if (ch === '\\r') { /* ignore */ }
      else cell += ch;
    }
  }
  if (cell.length || row.length) { row.push(cell); rows.push(row); }
  if (!rows.length) return [];
  const header = rows[0].map((h) => h.trim().toLowerCase());
  const lines = rows.slice(1);
  const idx = Object.fromEntries(header.map((h, i) => [h, i]));
  const get = (r, k) => r[idx[k]] ?? "";
  return lines
    .filter((r) => r.some((c) => c && c.trim().length))
    .map((r) => ({
      name: String(get(r, "name")),
      qty: Number(get(r, "qty")) || 0,
      unit: String(get(r, "unit")) || "g",
      packs: Number(get(r, "packs")) || 1,
      price: Number(get(r, "price")) || 0,
      percentOff: get(r, "percentoff") !== "" ? Number(get(r, "percentoff")) : undefined,
      flatOff: get(r, "flatoff") !== "" ? Number(get(r, "flatoff")) : undefined,
      buyX: get(r, "buyx") !== "" ? Number(get(r, "buyx")) : undefined,
      getY: get(r, "gety") !== "" ? Number(get(r, "gety")) : undefined,
      notes: String(get(r, "notes")) || undefined,
    }));
}

function downloadCSV(filename, text) {
  const blob = new Blob([text], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Helper: create a new default item for the Quick Add panel
function makeDefaultItem(unitKey) {
  return { name: "", qty: 100, unit: unitKey, packs: 1, price: 0 };
}

// ---------------------------- Core component --------------------------
export default function App() {
  const [kind, setKind] = useState("mass");
  const [currency, setCurrency] = useState("INR");
  const [baseSize, setBaseSize] = useState(100);
  const [items, setItems] = useState(DEFAULT_ITEMS);
  const [showPaste, setShowPaste] = useState(false);
  const [pasteText, setPasteText] = useState("");
  const [tests, setTests] = useState([]);

  // Quick Add form state (manual add without using CSV)
  const [qa, setQa] = useState(() => makeDefaultItem(KIND_UNITS["mass"][0].key));
  useEffect(() => {
    // keep unit list in sync when kind changes
    setQa((prev) => ({ ...prev, unit: KIND_UNITS[kind][0].key }));
  }, [kind]);

  // Load / Save (localStorage)
  useEffect(() => {
    try {
      const saved = localStorage.getItem("unitPriceItems_v3");
      const savedKind = localStorage.getItem("unitPriceKind_v3");
      const savedBase = localStorage.getItem("unitPriceBase_v3");
      const savedCur = localStorage.getItem("unitPriceCurrency_v3");
      if (saved) setItems(JSON.parse(saved));
      if (savedKind) setKind(savedKind);
      if (savedBase) setBaseSize(Number(savedBase));
      if (savedCur) setCurrency(savedCur);
    } catch {}
  }, []);
  useEffect(() => { try { localStorage.setItem("unitPriceItems_v3", JSON.stringify(items)); } catch {} }, [items]);
  useEffect(() => { try { localStorage.setItem("unitPriceKind_v3", kind); } catch {} }, [kind]);
  useEffect(() => { try { localStorage.setItem("unitPriceBase_v3", String(baseSize)); } catch {} }, [baseSize]);
  useEffect(() => { try { localStorage.setItem("unitPriceCurrency_v3", currency); } catch {} }, [currency]);

  const units = KIND_UNITS[kind];

  const rows = useMemo(() => {
    const uMap = Object.fromEntries(units.map((u) => [u.key, u]));
    const computed = items.map((it, idx) => {
      const unit = uMap[it.unit];
      const packs = isFinite(it.packs) && it.packs > 0 ? it.packs : 1;

      // Buy X Get Y free (applies on packs):
      let effectivePaidPacks = packs;
      if (it.buyX && it.getY && it.buyX > 0) {
        const group = it.buyX + it.getY;
        const groups = Math.floor(packs / group);
        effectivePaidPacks = packs - groups * (it.getY || 0);
      }

      const totalBaseQty = unit ? unit.toBase(it.qty) * packs : NaN; // quantity doesn't change with BxGy, only price does

      // Price discounts: percent, then flat
      let effectivePrice = it.price;
      if (isFinite(it.percentOff) && (it.percentOff || 0) > 0) {
        effectivePrice = effectivePrice * (1 - Math.min(Math.max(it.percentOff, 0), 100) / 100);
      }
      if (isFinite(it.flatOff) && (it.flatOff || 0) > 0) {
        effectivePrice = Math.max(0, effectivePrice - it.flatOff);
      }

      // Adjust for BxGy (you pay for fewer packs):
      if (effectivePaidPacks !== packs && packs > 0) {
        const pricePerPack = effectivePrice / packs;
        effectivePrice = pricePerPack * effectivePaidPacks;
      }

      const perBaseUnitPrice = totalBaseQty > 0 ? effectivePrice / totalBaseQty : NaN;
      const perChosenBase = isFinite(perBaseUnitPrice) ? perBaseUnitPrice * baseSize : NaN;

      return {
        index: idx,
        ...it,
        totalBaseQty,
        effectivePaidPacks,
        effectivePrice,
        perChosenBase,
        isBest: false,
        diffPct: NaN,
      };
    });

    const valid = computed.filter((r) => isFinite(r.perChosenBase));
    const best = valid.length ? Math.min(...valid.map((r) => r.perChosenBase)) : NaN;
    const eps = 1e-9; // treat near-equal values as ties
    return computed.map((r) => ({
      ...r,
      isBest: isFinite(best) && isFinite(r.perChosenBase) && Math.abs(r.perChosenBase - best) <= eps,
      diffPct: isFinite(best) && isFinite(r.perChosenBase) ? (r.perChosenBase - best) / best : NaN,
    }));
  }, [items, units, baseSize]);

  function updateItem(idx, patch) {
    setItems((prev) => prev.map((it, i) => (i === idx ? { ...it, ...patch } : it)));
  }
  function addItem() {
    setItems((prev) => [
      ...prev,
      { name: "New item", qty: 100, unit: units[0].key, packs: 1, price: 0 },
    ]);
  }
  function addItemManual(it) {
    const cleaned = {
      name: (it.name || "New item").trim(),
      qty: Number(it.qty) || 0,
      unit: it.unit || units[0].key,
      packs: Number(it.packs) || 1,
      price: Number(it.price) || 0,
      percentOff: it.percentOff !== undefined && it.percentOff !== null && it.percentOff !== "" ? Number(it.percentOff) : undefined,
      flatOff: it.flatOff !== undefined && it.flatOff !== null && it.flatOff !== "" ? Number(it.flatOff) : undefined,
      buyX: it.buyX !== undefined && it.buyX !== null && it.buyX !== "" ? Number(it.buyX) : undefined,
      getY: it.getY !== undefined && it.getY !== null && it.getY !== "" ? Number(it.getY) : undefined,
      notes: it.notes?.trim() || undefined,
    };
    setItems((prev) => [...prev, cleaned]);
  }
  function removeItem(idx) { setItems((prev) => prev.filter((_, i) => i !== idx)); }
  function clearAll() { setItems([]); }
  function loadSample() { setKind("mass"); setBaseSize(100); setCurrency("INR"); setItems(DEFAULT_ITEMS); }

  function onExportCSV() {
    const csv = toCSV(items);
    downloadCSV(`unit-prices-${Date.now()}.csv`, csv);
  }

  function onImportFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const text = String(reader.result || "");
        const parsed = parseCSV(text);
        if (!parsed.length) { alert("CSV parsed, but no rows detected."); return; }
        setItems(parsed);
      } catch (err) {
        alert("Import failed: " + (err?.message || String(err)));
      }
    };
    reader.readAsText(file);
    e.currentTarget.value = ""; // reset
  }

  // ------------------------------ Tests --------------------------------
  useEffect(() => {
    const results = [];
    try {
      // Test 1: CSV roundtrip with commas, quotes, newlines
      const tricky = [
        { name: 'Milk, 1L', qty: 1, unit: 'l', packs: 1, price: 80, notes: 'Line1\\nLine2' },
        { name: 'Bread \"Whole\" 400g', qty: 400, unit: 'g', packs: 1, price: 45 },
      ];
      const csv = toCSV(tricky);
      const round = parseCSV(csv);
      results.push({ name: 'CSV roundtrip', pass: round.length === tricky.length && round[0].name === tricky[0].name && round[0].notes === tricky[0].notes, info: { csv, round, tricky } });

      // Test 2: CRLF handling
      const crlf = 'name,qty,unit,packs,price\\r\\nTea,100,g,1,50\\r\\n';
      const parsedCRLF = parseCSV(crlf);
      results.push({ name: 'CRLF parse', pass: parsedCRLF.length === 1 && parsedCRLF[0].name === 'Tea' && parsedCRLF[0].qty === 100, info: parsedCRLF });

      // Test 3: Empty cells + numeric coercion
      const withEmpties = 'name,qty,unit,packs,price\\nSugar,,g,,45\\n';
      const parsedEmpties = parseCSV(withEmpties);
      results.push({ name: 'Empty cells coercion', pass: parsedEmpties.length === 1 && parsedEmpties[0].name === 'Sugar' && parsedEmpties[0].qty === 0 && parsedEmpties[0].packs === 1, info: parsedEmpties });

      // Test 4: Promo stacking math (percent then flat)
      const priceAfterPercent = 100 * (1 - 0.10); // 90
      const priceAfterFlat = Math.max(0, priceAfterPercent - 10); // 80
      results.push({ name: 'Promo math', pass: priceAfterFlat === 80, info: { priceAfterPercent, priceAfterFlat } });

      // Test 5: Buy X Get Y calculation
      const packs = 5, buyX = 2, getY = 1; // groups of 3 -> 1 free in 5 -> pay 4
      const groups = Math.floor(packs / (buyX + getY));
      const effectivePaid = packs - groups * getY;
      results.push({ name: 'BxGy math', pass: effectivePaid === 4, info: { packs, buyX, getY, effectivePaid } });

      // Test 6: Tie detection logic (equal unit price)
      const aPricePer100 = (200 / (2 * 100)) * 100; // 200 for 200g -> per100 = 100
      const bPricePer100 = (500 / (5 * 100)) * 100; // 500 for 500g -> per100 = 100
      results.push({ name: 'Tie detection math', pass: aPricePer100 === bPricePer100, info: { aPricePer100, bPricePer100 } });

      // Test 7: Manual add increases length
      {
        const start = [{ name: 'A', qty: 100, unit: 'g', packs: 1, price: 10 } ];
        const added = [...start, { name: 'B', qty: 200, unit: 'g', packs: 1, price: 15 }];
        results.push({ name: 'Manual add increases length', pass: added.length === 2 });
      }
    } catch (e) {
      results.push({ name: 'Self-tests error', pass: false, info: e });
    }
    setTests(results);
  }, []);

  // ------------------------------- UI ----------------------------------
  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <h1 style={styles.h1}>Unit Price Comparator</h1>
        <div style={styles.sub}>Compare fairly across sizes, multipacks, and promos.</div>

        <div style={styles.card}>
          <div style={{ ...styles.row, justifyContent: 'space-between' }}>
            <div>
              <div style={styles.label}>Measure type</div>
              <select value={kind} onChange={(e) => setKind(e.target.value)} style={styles.select}>
                <option value="mass">Mass (g/kg)</option>
                <option value="volume">Volume (ml/L)</option>
                <option value="count">Count (per piece)</option>
              </select>
            </div>

            <div>
              <div style={styles.label}>Normalize to</div>
              <div style={styles.row}>
                <input type="number" value={baseSize} min={1} onChange={(e) => setBaseSize(Math.max(1, Number(e.target.value) || 1))} style={styles.input} />
                <span>{kind === 'mass' ? 'g' : kind === 'volume' ? 'ml' : 'unit(s)'}</span>
              </div>
              <div style={{ ...styles.label, marginTop: 4 }}>All prices shown per this amount.</div>
            </div>

            <div>
              <div style={styles.label}>Currency (ISO or symbol)</div>
              <input value={currency} onChange={(e) => setCurrency(e.target.value)} style={styles.input} />
            </div>
          </div>

          <div style={{ ...styles.row, marginTop: 8 }}>
            <button onClick={loadSample} style={styles.btn}>Load Sample</button>
            <button onClick={addItem} style={styles.btnFilled}>Add Item</button>
            <button onClick={clearAll} style={styles.btn}>Clear</button>
            <label style={styles.btn}>
              Import CSV<input type="file" accept=".csv,text/csv,text/plain" onChange={onImportFile} style={{ display: 'none' }} />
            </label>
            <button onClick={() => setShowPaste((s) => !s)} style={styles.btn}>Paste CSV</button>
            <button onClick={() => onExportCSV()} style={styles.btn}>Export CSV</button>
          </div>

          {showPaste && (
            <div>
              <div style={{ ...styles.sub, marginTop: 10 }}>Paste CSV</div>
              <textarea style={styles.pasteBox} value={pasteText} onChange={(e) => setPasteText(e.target.value)} placeholder={"name,qty,unit,packs,price\nCoffee 100 g,100,g,1,149"} />
              <div style={{ ...styles.row, marginTop: 8 }}>
                <button
                  onClick={() => {
                    const parsed = parseCSV(pasteText);
                    if (!parsed.length) { alert("CSV parsed, but no rows detected."); return; }
                    setItems(parsed);
                    setShowPaste(false);
                  }}
                  style={styles.btnFilled}
                >Import from text</button>
                <button onClick={() => setShowPaste(false)} style={styles.btn}>Cancel</button>
              </div>
            </div>
          )}
        </div>

        {/* Quick Add panel */}
        <div style={styles.card}>
          <div style={{ ...styles.row, alignItems: 'flex-end' }}>
            <div>
              <div style={styles.label}>Item name</div>
              <input style={styles.input} value={qa.name} onChange={(e) => setQa({ ...qa, name: e.target.value })} placeholder="e.g., Coffee 200 g" />
            </div>
            <div>
              <div style={styles.label}>Qty</div>
              <input type="number" style={styles.input} value={qa.qty} onChange={(e) => setQa({ ...qa, qty: Number(e.target.value) || 0 })} />
            </div>
            <div>
              <div style={styles.label}>Unit</div>
              <select value={qa.unit} onChange={(e) => setQa({ ...qa, unit: e.target.value })} style={styles.select}>
                {KIND_UNITS[kind].map((u) => (
                  <option key={u.key} value={u.key}>{u.label}</option>
                ))}
              </select>
            </div>
            <div>
              <div style={styles.label}>×Packs</div>
              <input type="number" style={styles.input} value={qa.packs ?? 1} onChange={(e) => setQa({ ...qa, packs: Number(e.target.value) || 1 })} />
            </div>
            <div>
              <div style={styles.label}>Price</div>
              <input type="number" style={styles.input} value={qa.price} onChange={(e) => setQa({ ...qa, price: Number(e.target.value) || 0 })} />
            </div>
            <div>
              <div style={styles.label}>% off</div>
              <input type="number" style={styles.input} value={qa.percentOff ?? ''} onChange={(e) => setQa({ ...qa, percentOff: e.target.value === '' ? undefined : Number(e.target.value) || 0 })} />
            </div>
            <div>
              <div style={styles.label}>Flat off</div>
              <input type="number" style={styles.input} value={qa.flatOff ?? ''} onChange={(e) => setQa({ ...qa, flatOff: e.target.value === '' ? undefined : Number(e.target.value) || 0 })} />
            </div>
            <div>
              <div style={styles.label}>Buy X</div>
              <input type="number" style={styles.input} value={qa.buyX ?? ''} onChange={(e) => setQa({ ...qa, buyX: e.target.value === '' ? undefined : Number(e.target.value) || 0 })} />
            </div>
            <div>
              <div style={styles.label}>Get Y</div>
              <input type="number" style={styles.input} value={qa.getY ?? ''} onChange={(e) => setQa({ ...qa, getY: e.target.value === '' ? undefined : Number(e.target.value) || 0 })} />
            </div>
            <div style={{ alignSelf: 'center' }}>
              <button
                onClick={() => { addItemManual(qa); setQa(makeDefaultItem(KIND_UNITS[kind][0].key)); }}
                style={styles.btnFilled}
                title="Add this product"
              >Add product</button>
            </div>
          </div>
        </div>

        <div style={styles.card}>
          <div style={styles.headerRow}>
            <div>Item</div>
            <div>Qty</div>
            <div>Unit</div>
            <div>×Packs</div>
            <div>Price</div>
            <div>Promos</div>
            <div>Per base</div>
            <div></div>
          </div>

          {rows.map((r) => (
            <div key={r.index} style={{ ...styles.itemRow, background: r.isBest ? '#ecfdf5' : undefined, borderRadius: r.isBest ? 12 : undefined }}>
              <input style={{ ...styles.smallInput, width: '100%' }} value={r.name} onChange={(e) => updateItem(r.index, { name: e.target.value })} />

              <input type="number" style={styles.smallInput} value={r.qty} onChange={(e) => updateItem(r.index, { qty: Number(e.target.value) || 0 })} />

              <select value={r.unit} onChange={(e) => updateItem(r.index, { unit: e.target.value })} style={styles.select}>
                {units.map((u) => (
                  <option key={u.key} value={u.key}>{u.label}</option>
                ))}
              </select>

              <input type="number" style={styles.smallInput} value={r.packs} onChange={(e) => updateItem(r.index, { packs: Number(e.target.value) || 1 })} />

              <input type="number" style={styles.smallInput} value={r.price} onChange={(e) => updateItem(r.index, { price: Number(e.target.value) || 0 })} />

              <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                <input placeholder="% off" type="number" style={{ ...styles.smallInput, width: 80 }} value={r.percentOff ?? ''} onChange={(e) => updateItem(r.index, { percentOff: e.target.value === '' ? undefined : Number(e.target.value) || 0 })} />
                <input placeholder="Flat off" type="number" style={{ ...styles.smallInput, width: 100 }} value={r.flatOff ?? ''} onChange={(e) => updateItem(r.index, { flatOff: e.target.value === '' ? undefined : Number(e.target.value) || 0 })} />
                <input placeholder="Buy X" type="number" style={{ ...styles.smallInput, width: 80 }} value={r.buyX ?? ''} onChange={(e) => updateItem(r.index, { buyX: e.target.value === '' ? undefined : Number(e.target.value) || 0 })} />
                <input placeholder="Get Y" type="number" style={{ ...styles.smallInput, width: 80 }} value={r.getY ?? ''} onChange={(e) => updateItem(r.index, { getY: e.target.value === '' ? undefined : Number(e.target.value) || 0 })} />
              </div>

              <div>
                <div style={{ fontWeight: 800 }}>{isFinite(r.perChosenBase) ? currencyFormat(r.perChosenBase, currency) : '-'}</div>
                {r.isBest ? (
                  <span style={styles.bestBadge}>Best value</span>
                ) : isFinite(r.diffPct) && r.diffPct > 0 ? (
                  <div style={{ color: '#475569', fontSize: 12 }}>{(r.diffPct * 100).toFixed(1)}% higher</div>
                ) : null}
              </div>

              <button onClick={() => removeItem(r.index)} style={styles.btn}>Delete</button>
            </div>
          ))}

          <div style={{ ...styles.sub, marginTop: 8 }}>
            Math: unit price = adjusted price ÷ total base quantity (shown per your chosen base size).
            Multipacks multiply quantity; BxGy reduces price by unpaid packs; percent/flat discounts apply before BxGy normalization.
          </div>
        </div>

        <div style={styles.card}>
          <div style={{ fontWeight: 800 }}>Self-tests</div>
          <ul>
            {tests.map((t, i) => (
              <li key={i} style={{ color: t.pass ? '#065f46' : '#b91c1c' }}>
                {t.pass ? '✓' : '✗'} {t.name}
              </li>
            ))}
          </ul>
        </div>

        <div style={{ ...styles.sub, textAlign: 'center', marginTop: 16 }}>
          Built for quick grocery math — coffee, rice, oils, detergent, anything.
        </div>
      </div>
    </div>
  );
}
