# Unit Price Comparator (Web)
Run locally:

```bash
npm i
npm run dev
```

Build:
```bash
npm run build
npm run preview
```
